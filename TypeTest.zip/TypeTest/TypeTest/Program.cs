﻿
namespace TypeTest
{
    class Program
    {
        static void Main(string[] args)
        {
            TypeTester tt = new("records.json", "Тест на скоропечатанье отличный способ посоревноваться с другими и повысить скорость своей печати на клавиатуре");
            tt.Run();
        }
    }
}